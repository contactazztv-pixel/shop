const express = require('express');
const passport = require('passport');
const router = express.Router();

// Bắt đầu đăng nhập Discord
router.get('/login', (req, res, next) => {
  if (req.isAuthenticated()) return res.redirect('/dashboard');
  next();
}, passport.authenticate('discord'));

// Callback sau khi Discord xác thực
router.get('/discord/callback',
  passport.authenticate('discord', {
    failureRedirect: '/?error=auth_failed'
  }),
  (req, res) => {
    const returnTo = req.session.returnTo || '/dashboard';
    delete req.session.returnTo;
    res.redirect(returnTo);
  }
);

// Đăng xuất
router.get('/logout', (req, res, next) => {
  req.logout((err) => {
    if (err) return next(err);
    req.session.destroy(() => {
      res.redirect('/');
    });
  });
});

module.exports = router;
