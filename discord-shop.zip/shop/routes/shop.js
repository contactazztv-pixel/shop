const express = require('express');
const router = express.Router();
const { isAuthenticated } = require('../middleware/auth');
const Product = require('../models/Product');
const Order = require('../models/Order');
const Transaction = require('../models/Transaction');
const User = require('../models/User');
const axios = require('axios');

// Trang chủ / shop
router.get('/', async (req, res) => {
  try {
    const products = await Product.find({ isActive: true }).sort({ createdAt: -1 });
    res.render('index', { user: req.user || null, products });
  } catch (err) {
    res.render('index', { user: req.user || null, products: [] });
  }
});

// Dashboard người dùng
router.get('/dashboard', isAuthenticated, async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user._id })
      .populate('product')
      .sort({ createdAt: -1 })
      .limit(10);
    const transactions = await Transaction.find({ user: req.user._id })
      .sort({ createdAt: -1 })
      .limit(20);
    res.render('dashboard', { user: req.user, orders, transactions });
  } catch (err) {
    res.render('dashboard', { user: req.user, orders: [], transactions: [] });
  }
});

// Trang nạp tiền
router.get('/deposit', isAuthenticated, (req, res) => {
  res.render('deposit', { user: req.user });
});

// Mua hàng
router.post('/buy/:productId', isAuthenticated, async (req, res) => {
  try {
    const product = await Product.findById(req.params.productId);
    if (!product || !product.isActive) {
      return res.json({ success: false, message: 'Sản phẩm không tồn tại hoặc đã bị ẩn.' });
    }

    const quantity = parseInt(req.body.quantity) || 1;
    const total = product.price * quantity;

    // Kiểm tra stock
    if (product.stock !== -1 && product.stock < quantity) {
      return res.json({ success: false, message: 'Sản phẩm đã hết hàng!' });
    }

    // Kiểm tra số dư
    const user = await User.findById(req.user._id);
    if (user.balance < total) {
      return res.json({
        success: false,
        message: `Số dư không đủ. Cần ${total.toLocaleString('vi-VN')}đ, hiện có ${user.balance.toLocaleString('vi-VN')}đ.`
      });
    }

    // Tạo đơn hàng
    const order = new Order({
      user: user._id,
      product: product._id,
      productSnapshot: {
        name: product.name,
        price: product.price,
        type: product.type,
        server: product.server,
        emoji: product.emoji
      },
      amount: product.price,
      quantity,
      total,
      status: 'pending'
    });
    await order.save();

    // Trừ tiền + lưu transaction
    const balanceBefore = user.balance;
    user.balance -= total;
    if (product.stock !== -1) product.stock -= quantity;
    product.sold += quantity;
    await user.save();
    await product.save();

    await Transaction.create({
      user: user._id,
      type: 'purchase',
      amount: -total,
      balanceBefore,
      balanceAfter: user.balance,
      description: `Mua ${product.name} x${quantity}`,
      orderId: order.orderId
    });

    // Gửi webhook Discord (nếu có)
    if (process.env.DISCORD_WEBHOOK_URL) {
      sendOrderWebhook(order, user, product).catch(() => {});
    }

    res.json({
      success: true,
      orderId: order.orderId,
      total,
      newBalance: user.balance
    });
  } catch (err) {
    console.error(err);
    res.json({ success: false, message: 'Có lỗi xảy ra, vui lòng thử lại.' });
  }
});

async function sendOrderWebhook(order, user, product) {
  await axios.post(process.env.DISCORD_WEBHOOK_URL, {
    embeds: [{
      title: '🛒 Đơn hàng mới!',
      color: 0x5865F2,
      fields: [
        { name: 'Mã đơn', value: `\`${order.orderId}\``, inline: true },
        { name: 'Khách hàng', value: `${user.username} (<@${user.discordId}>)`, inline: true },
        { name: 'Sản phẩm', value: `${product.emoji} ${product.name}`, inline: true },
        { name: 'Số lượng', value: `${order.quantity}`, inline: true },
        { name: 'Tổng tiền', value: `${order.total.toLocaleString('vi-VN')}đ`, inline: true },
        { name: 'Trạng thái', value: '⏳ Chờ xử lý', inline: true }
      ],
      timestamp: new Date().toISOString(),
      footer: { text: 'Discord Shop' }
    }]
  });
}

module.exports = router;
