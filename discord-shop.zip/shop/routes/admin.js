const express = require('express');
const router = express.Router();
const { isAdmin } = require('../middleware/auth');
const Product = require('../models/Product');
const Order = require('../models/Order');
const User = require('../models/User');
const Transaction = require('../models/Transaction');

// Admin dashboard
router.get('/', isAdmin, async (req, res) => {
  try {
    const [totalOrders, pendingOrders, totalUsers, totalRevenue, products] = await Promise.all([
      Order.countDocuments(),
      Order.countDocuments({ status: 'pending' }),
      User.countDocuments(),
      Order.aggregate([
        { $match: { status: 'completed' } },
        { $group: { _id: null, total: { $sum: '$total' } } }
      ]),
      Product.countDocuments()
    ]);
    const recentOrders = await Order.find().populate('user').populate('product')
      .sort({ createdAt: -1 }).limit(5);

    res.render('admin/index', {
      user: req.user,
      stats: {
        totalOrders, pendingOrders, totalUsers,
        revenue: totalRevenue[0]?.total || 0,
        products
      },
      recentOrders
    });
  } catch (err) {
    console.error(err);
    res.render('admin/index', { user: req.user, stats: {}, recentOrders: [] });
  }
});

// ─── PRODUCTS ────────────────────────────────────────────────

router.get('/products', isAdmin, async (req, res) => {
  const products = await Product.find().sort({ createdAt: -1 });
  res.render('admin/products', { user: req.user, products });
});

router.post('/products/create', isAdmin, async (req, res) => {
  try {
    const { name, description, price, type, server, emoji, badge, badgeColor, stock } = req.body;
    await Product.create({
      name, description,
      price: Number(price),
      type, server,
      emoji: emoji || '🎁',
      badge, badgeColor,
      stock: stock ? Number(stock) : -1
    });
    res.json({ success: true, message: 'Tạo sản phẩm thành công!' });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

router.post('/products/update/:id', isAdmin, async (req, res) => {
  try {
    const { name, description, price, type, server, emoji, badge, badgeColor, stock, isActive } = req.body;
    await Product.findByIdAndUpdate(req.params.id, {
      name, description,
      price: Number(price),
      type, server,
      emoji: emoji || '🎁',
      badge, badgeColor,
      stock: stock !== undefined ? Number(stock) : -1,
      isActive: isActive === 'true' || isActive === true
    });
    res.json({ success: true, message: 'Cập nhật thành công!' });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

router.post('/products/delete/:id', isAdmin, async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Đã xóa sản phẩm!' });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

// ─── ORDERS ──────────────────────────────────────────────────

router.get('/orders', isAdmin, async (req, res) => {
  const { status, page = 1 } = req.query;
  const filter = status ? { status } : {};
  const limit = 20;
  const skip = (page - 1) * limit;
  const [orders, total] = await Promise.all([
    Order.find(filter).populate('user').populate('product')
      .sort({ createdAt: -1 }).skip(skip).limit(limit),
    Order.countDocuments(filter)
  ]);
  res.render('admin/orders', {
    user: req.user, orders,
    currentStatus: status || 'all',
    page: Number(page),
    totalPages: Math.ceil(total / limit)
  });
});

router.post('/orders/complete/:id', isAdmin, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.json({ success: false, message: 'Không tìm thấy đơn!' });
    order.status = 'completed';
    order.completedAt = new Date();
    order.adminNote = req.body.note || '';
    await order.save();
    res.json({ success: true, message: `Đã xác nhận đơn ${order.orderId}` });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

router.post('/orders/cancel/:id', isAdmin, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id).populate('user');
    if (!order) return res.json({ success: false, message: 'Không tìm thấy đơn!' });
    if (order.status === 'cancelled') return res.json({ success: false, message: 'Đơn đã bị huỷ rồi!' });

    const user = await User.findById(order.user._id);
    const balanceBefore = user.balance;
    user.balance += order.total;
    await user.save();

    await Transaction.create({
      user: user._id,
      type: 'refund',
      amount: order.total,
      balanceBefore,
      balanceAfter: user.balance,
      description: `Hoàn tiền đơn ${order.orderId}`,
      orderId: order.orderId,
      adminId: req.user.discordId
    });

    order.status = 'cancelled';
    await order.save();
    res.json({ success: true, message: `Đã huỷ và hoàn tiền đơn ${order.orderId}` });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

// ─── USERS ───────────────────────────────────────────────────

router.get('/users', isAdmin, async (req, res) => {
  const users = await User.find().sort({ createdAt: -1 });
  res.render('admin/users', { user: req.user, users });
});

// Cộng/trừ tiền user
router.post('/users/balance/:id', isAdmin, async (req, res) => {
  try {
    const { amount, description } = req.body;
    const amountNum = Number(amount);
    const targetUser = await User.findById(req.params.id);
    if (!targetUser) return res.json({ success: false, message: 'Không tìm thấy user!' });

    const balanceBefore = targetUser.balance;
    targetUser.balance = Math.max(0, targetUser.balance + amountNum);
    await targetUser.save();

    await Transaction.create({
      user: targetUser._id,
      type: amountNum > 0 ? 'deposit' : 'admin_adjust',
      amount: amountNum,
      balanceBefore,
      balanceAfter: targetUser.balance,
      description: description || (amountNum > 0 ? 'Admin nạp tiền' : 'Admin điều chỉnh'),
      adminId: req.user.discordId
    });

    res.json({
      success: true,
      message: `${amountNum > 0 ? 'Cộng' : 'Trừ'} ${Math.abs(amountNum).toLocaleString('vi-VN')}đ cho ${targetUser.username} thành công!`,
      newBalance: targetUser.balance
    });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

// Cấp / thu hồi admin
router.post('/users/toggle-admin/:id', isAdmin, async (req, res) => {
  try {
    const targetUser = await User.findById(req.params.id);
    if (!targetUser) return res.json({ success: false, message: 'Không tìm thấy user!' });
    targetUser.isAdmin = !targetUser.isAdmin;
    await targetUser.save();
    res.json({ success: true, message: `${targetUser.isAdmin ? 'Đã cấp' : 'Đã thu hồi'} quyền admin cho ${targetUser.username}` });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

module.exports = router;
