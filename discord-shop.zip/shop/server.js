require('dotenv').config();
const express = require('express');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const passport = require('passport');
const mongoose = require('mongoose');
const DiscordStrategy = require('passport-discord').Strategy;
const path = require('path');

const User = require('./models/User');

// ─── App init ────────────────────────────────────────────────
const app = express();
const PORT = process.env.PORT || 3000;

// ─── Connect MongoDB ─────────────────────────────────────────
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error('❌ MongoDB error:', err));

// ─── View Engine ─────────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ─── Static files ────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ─── Session ─────────────────────────────────────────────────
app.use(session({
  secret: process.env.SESSION_SECRET || 'secret',
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({ mongoUrl: process.env.MONGODB_URI }),
  cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 } // 7 days
}));

// ─── Passport ────────────────────────────────────────────────
app.use(passport.initialize());
app.use(passport.session());

const ADMIN_IDS = (process.env.ADMIN_IDS || '').split(',').map(id => id.trim()).filter(Boolean);

passport.use(new DiscordStrategy({
  clientID: process.env.DISCORD_CLIENT_ID,
  clientSecret: process.env.DISCORD_CLIENT_SECRET,
  callbackURL: process.env.DISCORD_CALLBACK_URL,
  scope: ['identify', 'email']
}, async (accessToken, refreshToken, profile, done) => {
  try {
    let user = await User.findOne({ discordId: profile.id });
    const isAdmin = ADMIN_IDS.includes(profile.id);

    if (user) {
      user.username = profile.username;
      user.discriminator = profile.discriminator || '0';
      user.avatar = profile.avatar;
      user.email = profile.email;
      user.lastLogin = new Date();
      if (isAdmin) user.isAdmin = true;
      await user.save();
    } else {
      user = await User.create({
        discordId: profile.id,
        username: profile.username,
        discriminator: profile.discriminator || '0',
        avatar: profile.avatar,
        email: profile.email,
        isAdmin
      });
    }
    return done(null, user);
  } catch (err) {
    return done(err, null);
  }
}));

passport.serializeUser((user, done) => done(null, user._id));
passport.deserializeUser(async (id, done) => {
  try {
    const user = await User.findById(id);
    done(null, user);
  } catch (err) {
    done(err, null);
  }
});

// ─── Local vars for all views ─────────────────────────────────
app.use((req, res, next) => {
  res.locals.user = req.user || null;
  next();
});

// ─── Routes ──────────────────────────────────────────────────
app.use('/auth', require('./routes/auth'));
app.use('/', require('./routes/shop'));
app.use('/admin', require('./routes/admin'));

// ─── Error pages ─────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).render('error', { user: req.user || null, code: 404, message: 'Trang không tồn tại.' });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).render('error', { user: req.user || null, code: 500, message: 'Lỗi máy chủ.' });
});

// ─── Start ───────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
  console.log(`🔑 Admin IDs: ${ADMIN_IDS.join(', ') || 'none configured'}`);
});
