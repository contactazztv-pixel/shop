const User = require('../models/User');

// Kiểm tra đã đăng nhập
function isAuthenticated(req, res, next) {
  if (req.isAuthenticated()) return next();
  req.session.returnTo = req.originalUrl;
  res.redirect('/auth/login');
}

// Kiểm tra quyền admin
function isAdmin(req, res, next) {
  if (req.isAuthenticated() && req.user.isAdmin) return next();
  if (!req.isAuthenticated()) return res.redirect('/auth/login');
  res.status(403).render('error', {
    user: req.user || null,
    code: 403,
    message: 'Bạn không có quyền truy cập trang này.'
  });
}

// Optional auth — không bắt buộc
function optionalAuth(req, res, next) {
  next();
}

module.exports = { isAuthenticated, isAdmin, optionalAuth };
