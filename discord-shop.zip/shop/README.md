# 🛒 Discord Shop

Website bán hàng tích hợp Discord OAuth2, MongoDB, giao diện iOS glassmorphism.

---

## ✨ Tính năng

- **Đăng nhập Discord OAuth2** — avatar, username, phân quyền
- **Ví tiền** — số dư, lịch sử giao dịch
- **Shop sản phẩm** — card đẹp, filter theo loại, mua 1 click
- **Đơn hàng** — mã đơn tự động, trạng thái realtime
- **Admin panel** — quản lý sản phẩm, đơn hàng, users, cộng/trừ tiền
- **Discord Webhook** — log đơn hàng vào channel Discord
- **Dark mode** + Toast notifications + Responsive mobile

---

## 🚀 Cài đặt

### 1. Clone & cài thư viện

```bash
git clone <repo>
cd discord-shop
npm install
```

### 2. Tạo file `.env`

```bash
cp .env.example .env
```

Chỉnh sửa `.env`:

```env
PORT=3000
MONGODB_URI=mongodb://localhost:27017/discord-shop
SESSION_SECRET=thay_bang_chuoi_ngau_nhien_dai

DISCORD_CLIENT_ID=lấy_từ_discord_developer_portal
DISCORD_CLIENT_SECRET=lấy_từ_discord_developer_portal
DISCORD_CALLBACK_URL=http://localhost:3000/auth/discord/callback

# Discord ID của bạn (bật Developer Mode → chuột phải user → Copy ID)
ADMIN_IDS=123456789012345678

# Tùy chọn: webhook log đơn hàng
DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/xxx/yyy
```

### 3. Tạo Discord Application

1. Truy cập https://discord.com/developers/applications
2. Tạo **New Application**
3. Vào tab **OAuth2** → copy **Client ID** và **Client Secret**
4. Thêm **Redirect URI**: `http://localhost:3000/auth/discord/callback`
5. Paste vào `.env`

### 4. Chạy server

```bash
# Development (auto-reload)
npm run dev

# Production
npm start
```

Mở trình duyệt: http://localhost:3000

---

## 📁 Cấu trúc

```
discord-shop/
├── server.js              # Entry point, Passport config
├── .env                   # Biến môi trường
├── models/
│   ├── User.js            # User + Discord info + balance
│   ├── Product.js         # Sản phẩm
│   ├── Order.js           # Đơn hàng
│   └── Transaction.js     # Lịch sử giao dịch
├── routes/
│   ├── auth.js            # /auth/login, /auth/discord/callback, /auth/logout
│   ├── shop.js            # /, /dashboard, /deposit, /buy/:id
│   └── admin.js           # /admin/**
├── middleware/
│   └── auth.js            # isAuthenticated, isAdmin
├── views/
│   ├── partials/
│   │   ├── header.ejs
│   │   └── footer.ejs
│   ├── index.ejs          # Trang shop
│   ├── dashboard.ejs      # Dashboard user
│   ├── deposit.ejs        # Nạp tiền
│   ├── error.ejs
│   └── admin/
│       ├── index.ejs      # Admin dashboard
│       ├── products.ejs   # Quản lý sản phẩm
│       ├── orders.ejs     # Quản lý đơn hàng
│       └── users.ejs      # Quản lý users
└── public/
    ├── css/style.css
    └── js/main.js
```

---

## 🔑 Phân quyền

- **Admin**: Discord ID trong `ADMIN_IDS` (`.env`) hoặc được cấp qua Admin Panel
- **User**: Bất kỳ ai đăng nhập bằng Discord

### Cấp quyền admin thủ công:
Truy cập `/admin/users` → click **👑 Role** bên cạnh user

---

## 💰 Nạp tiền

Hiện tại dùng quy trình thủ công:
1. User chuyển khoản với nội dung `NAP <discord_id>`
2. Admin vào `/admin/users` → click **💰 Tiền** → nhập số tiền

### Tích hợp QR thật (VietQR):
Thay URL trong `deposit.ejs`:
```
https://img.vietqr.io/image/{BANK_ID}-{ACCOUNT_NO}-{TEMPLATE}.png?amount={AMOUNT}&addInfo={INFO}
```

---

## 🔗 Discord Webhook

Thêm `DISCORD_WEBHOOK_URL` vào `.env` để tự động gửi log đơn hàng mới vào channel Discord.

---

## 🌐 Deploy production

### Railway / Render / VPS:

1. Set các biến môi trường
2. Đổi `DISCORD_CALLBACK_URL` thành domain thật
3. Thêm redirect URI mới trong Discord Developer Portal

```env
DISCORD_CALLBACK_URL=https://yourdomain.com/auth/discord/callback
```

---

## 📦 Dependencies

| Package | Mục đích |
|---------|---------|
| express | Web framework |
| mongoose | MongoDB ODM |
| passport + passport-discord | Discord OAuth2 |
| express-session | Session management |
| connect-mongo | Lưu session vào MongoDB |
| ejs | Template engine |
| axios | HTTP client (webhook) |
| dotenv | Biến môi trường |
