'use strict';
const express     = require('express');
const router      = express.Router();
const { isAdmin } = require('../middleware/auth');
const Product     = require('../models/Product');
const Order       = require('../models/Order');
const User        = require('../models/User');
const Transaction = require('../models/Transaction');

// ── Dashboard ─────────────────────────────────────────────
router.get('/', isAdmin, async (req, res, next) => {
  try {
    const [totalOrders, pendingOrders, totalUsers, revenueAgg, totalProducts] = await Promise.all([
      Order.countDocuments(),
      Order.countDocuments({ status: 'pending' }),
      User.countDocuments(),
      Order.aggregate([{ $match: { status: 'completed' } }, { $group: { _id: null, total: { $sum: '$total' } } }]),
      Product.countDocuments(),
    ]);
    const recentOrders = await Order.find().populate('user','username discordId avatar discriminator').sort({ createdAt: -1 }).limit(8).lean();
    // Thêm avatarURL cho mỗi user trong lean
    recentOrders.forEach(o => {
      if (o.user) {
        o.user.avatarURL = o.user.avatar
          ? `https://cdn.discordapp.com/avatars/${o.user.discordId}/${o.user.avatar}.png`
          : `https://cdn.discordapp.com/embed/avatars/${parseInt(o.user.discriminator||0)%5}.png`;
      }
    });
    res.render('admin/index', {
      user: req.user,
      stats: { totalOrders, pendingOrders, totalUsers, revenue: revenueAgg[0]?.total||0, totalProducts },
      recentOrders,
    });
  } catch (err) { next(err); }
});

// ════════════════ PRODUCTS ════════════════════════════════

router.get('/products', isAdmin, async (req, res, next) => {
  try {
    const products = await Product.find().sort({ createdAt: -1 }).lean();
    res.render('admin/products', { user: req.user, products });
  } catch (err) { next(err); }
});

router.post('/products/create', isAdmin, async (req, res) => {
  try {
    const { name, description, price, type, server, emoji, badge, badgeColor, stock } = req.body;
    if (!name || !price) return res.json({ success: false, message: 'Thiếu tên hoặc giá!' });
    await Product.create({
      name: name.trim(), description: description?.trim() || '',
      price: Number(price), type: type || 'other',
      server: server?.trim() || '', emoji: emoji?.trim() || '🎁',
      badge: badge?.trim() || '', badgeColor: badgeColor || 'blue',
      stock: stock !== undefined && stock !== '' ? Number(stock) : -1,
    });
    res.json({ success: true, message: 'Tạo sản phẩm thành công!' });
  } catch (err) { res.json({ success: false, message: err.message }); }
});

router.post('/products/update/:id', isAdmin, async (req, res) => {
  try {
    const { name, description, price, type, server, emoji, badge, badgeColor, stock, isActive } = req.body;
    await Product.findByIdAndUpdate(req.params.id, {
      name: name?.trim(), description: description?.trim() || '',
      price: Number(price), type, server: server?.trim() || '',
      emoji: emoji?.trim() || '🎁', badge: badge?.trim() || '', badgeColor,
      stock: stock !== undefined && stock !== '' ? Number(stock) : -1,
      isActive: isActive === 'true' || isActive === true,
    }, { runValidators: true });
    res.json({ success: true, message: 'Cập nhật thành công!' });
  } catch (err) { res.json({ success: false, message: err.message }); }
});

router.post('/products/delete/:id', isAdmin, async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Đã xóa sản phẩm!' });
  } catch (err) { res.json({ success: false, message: err.message }); }
});

// ════════════════ ORDERS ══════════════════════════════════

router.get('/orders', isAdmin, async (req, res, next) => {
  try {
    const { status, page = 1 } = req.query;
    const filter = status && status !== 'all' ? { status } : {};
    const limit  = 20;
    const skip   = (Number(page) - 1) * limit;
    const [orders, total] = await Promise.all([
      Order.find(filter)
        .populate('user', 'username discordId avatar discriminator')
        .sort({ createdAt: -1 }).skip(skip).limit(limit).lean(),
      Order.countDocuments(filter),
    ]);
    orders.forEach(o => {
      if (o.user) {
        o.user.avatarURL = o.user.avatar
          ? `https://cdn.discordapp.com/avatars/${o.user.discordId}/${o.user.avatar}.png`
          : `https://cdn.discordapp.com/embed/avatars/${parseInt(o.user.discriminator||0)%5}.png`;
      }
    });
    res.render('admin/orders', {
      user: req.user, orders,
      currentStatus: status || 'all',
      page: Number(page),
      totalPages: Math.ceil(total / limit),
    });
  } catch (err) { next(err); }
});

router.post('/orders/complete/:id', isAdmin, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.json({ success: false, message: 'Không tìm thấy đơn!' });
    if (order.status === 'completed') return res.json({ success: false, message: 'Đơn đã hoàn thành rồi!' });
    order.status      = 'completed';
    order.completedAt = new Date();
    order.adminNote   = (req.body.note || '').trim();
    await order.save();
    res.json({ success: true, message: `Đã xác nhận đơn ${order.orderId}` });
  } catch (err) { res.json({ success: false, message: err.message }); }
});

router.post('/orders/cancel/:id', isAdmin, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id).populate('user');
    if (!order) return res.json({ success: false, message: 'Không tìm thấy đơn!' });
    if (order.status === 'cancelled') return res.json({ success: false, message: 'Đơn đã bị huỷ rồi!' });
    if (order.status === 'completed')  return res.json({ success: false, message: 'Không thể huỷ đơn đã hoàn thành!' });

    const user = await User.findById(order.user._id || order.user);
    if (user) {
      const balanceBefore = user.balance;
      user.balance += order.total;
      await user.save();
      await Transaction.create({
        user: user._id, type: 'refund', amount: order.total,
        balanceBefore, balanceAfter: user.balance,
        description: `Hoàn tiền đơn ${order.orderId}`, orderId: order.orderId,
        adminId: req.user.discordId,
      });
    }
    order.status = 'cancelled';
    await order.save();
    res.json({ success: true, message: `Đã huỷ và hoàn tiền đơn ${order.orderId}` });
  } catch (err) { res.json({ success: false, message: err.message }); }
});

// ════════════════ USERS ═══════════════════════════════════

router.get('/users', isAdmin, async (req, res, next) => {
  try {
    const users = await User.find().sort({ createdAt: -1 }).lean();
    users.forEach(u => {
      u.avatarURL = u.avatar
        ? `https://cdn.discordapp.com/avatars/${u.discordId}/${u.avatar}.png`
        : `https://cdn.discordapp.com/embed/avatars/${parseInt(u.discriminator||0)%5}.png`;
    });
    res.render('admin/users', { user: req.user, users });
  } catch (err) { next(err); }
});

router.post('/users/balance/:id', isAdmin, async (req, res) => {
  try {
    const amountNum = Number(req.body.amount);
    if (isNaN(amountNum) || amountNum === 0) return res.json({ success: false, message: 'Số tiền không hợp lệ!' });
    const targetUser = await User.findById(req.params.id);
    if (!targetUser) return res.json({ success: false, message: 'Không tìm thấy user!' });

    const balanceBefore = targetUser.balance;
    targetUser.balance  = Math.max(0, targetUser.balance + amountNum);
    await targetUser.save();

    await Transaction.create({
      user: targetUser._id,
      type: amountNum > 0 ? 'deposit' : 'admin_adjust',
      amount: amountNum, balanceBefore, balanceAfter: targetUser.balance,
      description: (req.body.description || '').trim() || (amountNum > 0 ? 'Admin nạp tiền' : 'Admin điều chỉnh'),
      adminId: req.user.discordId,
    });

    res.json({
      success: true,
      message: `${amountNum > 0 ? 'Cộng' : 'Trừ'} ${Math.abs(amountNum).toLocaleString('vi-VN')}đ cho ${targetUser.username} thành công!`,
      newBalance: targetUser.balance,
    });
  } catch (err) { res.json({ success: false, message: err.message }); }
});

router.post('/users/toggle-admin/:id', isAdmin, async (req, res) => {
  try {
    const targetUser = await User.findById(req.params.id);
    if (!targetUser) return res.json({ success: false, message: 'Không tìm thấy user!' });
    if (targetUser.discordId === req.user.discordId) return res.json({ success: false, message: 'Không thể tự thu hồi quyền của chính mình!' });
    targetUser.isAdmin = !targetUser.isAdmin;
    await targetUser.save();
    res.json({ success: true, message: `${targetUser.isAdmin ? '✅ Đã cấp' : '❌ Đã thu hồi'} quyền admin cho ${targetUser.username}` });
  } catch (err) { res.json({ success: false, message: err.message }); }
});

module.exports = router;
