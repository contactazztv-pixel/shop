'use strict';
const express     = require('express');
const router      = express.Router();
const axios       = require('axios');
const { isAuthenticated } = require('../middleware/auth');
const Product     = require('../models/Product');
const Order       = require('../models/Order');
const Transaction = require('../models/Transaction');
const User        = require('../models/User');

// ── Trang chủ / Shop ───────────────────────────────────────
router.get('/', async (req, res, next) => {
  try {
    const products = await Product.find({ isActive: true }).sort({ createdAt: -1 }).lean();
    res.render('index', { user: req.user || null, products });
  } catch (err) { next(err); }
});

// ── Dashboard ─────────────────────────────────────────────
router.get('/dashboard', isAuthenticated, async (req, res, next) => {
  try {
    const [orders, transactions] = await Promise.all([
      Order.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(10).lean(),
      Transaction.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(20).lean(),
    ]);
    res.render('dashboard', { user: req.user, orders, transactions });
  } catch (err) { next(err); }
});

// ── Nạp tiền ──────────────────────────────────────────────
router.get('/deposit', isAuthenticated, (req, res) => {
  res.render('deposit', { user: req.user });
});

// ── Mua hàng ──────────────────────────────────────────────
router.post('/buy/:productId', isAuthenticated, async (req, res) => {
  try {
    const product = await Product.findById(req.params.productId);
    if (!product || !product.isActive) {
      return res.status(404).json({ success: false, message: 'Sản phẩm không tồn tại hoặc đã bị ẩn.' });
    }

    const quantity = Math.max(1, parseInt(req.body.quantity) || 1);
    const total    = product.price * quantity;

    if (product.stock !== -1 && product.stock < quantity) {
      return res.status(400).json({ success: false, message: 'Sản phẩm đã hết hàng!' });
    }

    // Lấy user mới nhất từ DB (tránh dùng session cache)
    const user = await User.findById(req.user._id);
    if (!user) return res.status(401).json({ success: false, message: 'Vui lòng đăng nhập lại.' });

    if (user.balance < total) {
      return res.status(400).json({
        success: false,
        message: `Số dư không đủ. Cần ${total.toLocaleString('vi-VN')}đ, hiện có ${user.balance.toLocaleString('vi-VN')}đ.`,
      });
    }

    // Tạo đơn hàng
    const order = await Order.create({
      user:            user._id,
      product:         product._id,
      productSnapshot: { name: product.name, price: product.price, type: product.type, server: product.server, emoji: product.emoji },
      amount:          product.price,
      quantity,
      total,
      status:          'pending',
    });

    // Trừ tiền & cập nhật stock
    const balanceBefore = user.balance;
    user.balance -= total;
    if (product.stock !== -1) product.stock = Math.max(0, product.stock - quantity);
    product.sold += quantity;

    await Promise.all([user.save(), product.save()]);

    // Lưu transaction
    await Transaction.create({
      user:          user._id,
      type:          'purchase',
      amount:        -total,
      balanceBefore,
      balanceAfter:  user.balance,
      description:   `Mua ${product.name} x${quantity}`,
      orderId:       order.orderId,
    });

    // Webhook Discord
    if (process.env.DISCORD_WEBHOOK_URL) {
      sendOrderWebhook(order, user, product).catch(e => console.error('Webhook error:', e.message));
    }

    res.json({ success: true, orderId: order.orderId, total, newBalance: user.balance });
  } catch (err) {
    console.error('[BUY]', err);
    res.status(500).json({ success: false, message: 'Lỗi máy chủ, vui lòng thử lại.' });
  }
});

// ── Discord Webhook ────────────────────────────────────────
async function sendOrderWebhook(order, user, product) {
  await axios.post(process.env.DISCORD_WEBHOOK_URL, {
    embeds: [{
      title: '🛒 Đơn hàng mới!',
      color: 0x5865F2,
      thumbnail: { url: user.avatar ? `https://cdn.discordapp.com/avatars/${user.discordId}/${user.avatar}.png` : '' },
      fields: [
        { name: 'Mã đơn',     value: `\`${order.orderId}\``,                              inline: true },
        { name: 'Khách hàng', value: `${user.username} (<@${user.discordId}>)`,           inline: true },
        { name: 'Sản phẩm',   value: `${product.emoji} ${product.name}`,                 inline: true },
        { name: 'Số lượng',   value: `${order.quantity}`,                                 inline: true },
        { name: 'Tổng tiền',  value: `${order.total.toLocaleString('vi-VN')}đ`,           inline: true },
        { name: 'Trạng thái', value: '⏳ Chờ xử lý',                                      inline: true },
      ],
      timestamp: new Date().toISOString(),
      footer: { text: 'Discord Shop System' },
    }],
  }, { timeout: 5000 });
}

module.exports = router;
