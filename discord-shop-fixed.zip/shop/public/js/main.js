/* ── Theme — apply BEFORE render để tránh flash ─────────── */
(function () {
  var t = localStorage.getItem('theme');
  var d = window.matchMedia('(prefers-color-scheme: dark)').matches;
  if (t === 'dark' || (t === null && d)) document.documentElement.classList.add('dark');
})();

/* ── DOMContentLoaded ────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function () {

  // Dark mode toggle
  var toggle = document.getElementById('themeToggle');
  if (toggle) {
    toggle.addEventListener('click', function () {
      var isDark = document.documentElement.classList.toggle('dark');
      localStorage.setItem('theme', isDark ? 'dark' : 'light');
    });
  }

  // Close modal khi click overlay
  document.querySelectorAll('.modal-overlay').forEach(function (overlay) {
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) closeAllModals();
    });
  });

  // Close modal khi nhấn Escape
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeAllModals();
  });

  // Tự động ẩn URL error param (tránh hiện lỗi khi refresh)
  if (window.location.search.includes('error=')) {
    var params = new URLSearchParams(window.location.search);
    if (params.get('error') === 'auth_failed') {
      showToast('error', 'Đăng nhập Discord thất bại. Vui lòng thử lại.');
    }
    history.replaceState({}, '', window.location.pathname);
  }
});

/* ── Close all modals ────────────────────────────────────── */
function closeAllModals() {
  document.querySelectorAll('.modal-overlay').forEach(function (m) {
    if (!m.classList.contains('hidden')) {
      m.classList.add('hidden');
      m.classList.remove('flex');
    }
  });
}

/* ── Toast Notification ──────────────────────────────────── */
function showToast(type, message, duration) {
  duration = duration || 4000;
  var container = document.getElementById('toastContainer');
  if (!container) return;

  var icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
  var toast = document.createElement('div');
  toast.className = 'toast toast-' + type;
  toast.innerHTML =
    '<span class="text-lg shrink-0">' + (icons[type] || icons.info) + '</span>' +
    '<span class="flex-1 leading-snug">' + message + '</span>' +
    '<button onclick="removeToast(this.parentElement)" class="shrink-0 opacity-60 hover:opacity-100 text-lg leading-none ml-1">×</button>';

  container.appendChild(toast);
  if (duration > 0) setTimeout(function () { removeToast(toast); }, duration);
  return toast;
}

function removeToast(toast) {
  if (!toast || toast.classList.contains('removing')) return;
  toast.classList.add('removing');
  toast.addEventListener('animationend', function () { toast.remove(); }, { once: true });
}

/* ── Format số tiền ─────────────────────────────────────── */
function formatVND(amount) {
  return new Intl.NumberFormat('vi-VN').format(amount) + 'đ';
}
