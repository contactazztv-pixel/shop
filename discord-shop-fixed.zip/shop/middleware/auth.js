'use strict';
// ─── Auth Middleware ───────────────────────────────────────

function isAuthenticated(req, res, next) {
  if (req.isAuthenticated && req.isAuthenticated()) return next();
  if (req.xhr || req.headers.accept?.includes('application/json')) {
    return res.status(401).json({ success: false, message: 'Vui lòng đăng nhập.' });
  }
  req.session.returnTo = req.originalUrl;
  res.redirect('/auth/login');
}

function isAdmin(req, res, next) {
  if (req.isAuthenticated && req.isAuthenticated() && req.user?.isAdmin) return next();
  if (!req.isAuthenticated || !req.isAuthenticated()) {
    if (req.xhr || req.headers.accept?.includes('application/json')) {
      return res.status(401).json({ success: false, message: 'Vui lòng đăng nhập.' });
    }
    req.session.returnTo = req.originalUrl;
    return res.redirect('/auth/login');
  }
  if (req.xhr || req.headers.accept?.includes('application/json')) {
    return res.status(403).json({ success: false, message: 'Không có quyền.' });
  }
  res.status(403).render('error', {
    user: req.user || null, code: 403, message: 'Bạn không có quyền truy cập trang này.',
  });
}

module.exports = { isAuthenticated, isAdmin };
