'use strict';
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  discordId:     { type: String, required: true, unique: true, index: true },
  username:      { type: String, required: true },
  discriminator: { type: String, default: '0' },
  avatar:        { type: String, default: null },
  email:         { type: String, default: null },
  balance:       { type: Number, default: 0, min: 0 },
  isAdmin:       { type: Boolean, default: false },
  createdAt:     { type: Date, default: Date.now },
  lastLogin:     { type: Date, default: Date.now },
});

// Virtual avatarURL (dùng khi KHÔNG lean())
userSchema.virtual('avatarURL').get(function () {
  if (this.avatar) return `https://cdn.discordapp.com/avatars/${this.discordId}/${this.avatar}.png`;
  return `https://cdn.discordapp.com/embed/avatars/${parseInt(this.discriminator || 0) % 5}.png`;
});

userSchema.set('toJSON',   { virtuals: true });
userSchema.set('toObject', { virtuals: true });

module.exports = mongoose.model('User', userSchema);
