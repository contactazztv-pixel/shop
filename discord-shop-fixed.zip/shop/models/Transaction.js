const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  type: {
    type: String,
    enum: ['deposit', 'purchase', 'refund', 'admin_adjust'],
    required: true
  },
  amount: { type: Number, required: true }, // positive = thêm, negative = trừ
  balanceBefore: { type: Number, required: true },
  balanceAfter: { type: Number, required: true },
  description: { type: String, default: '' },
  orderId: { type: String },
  adminId: { type: String }, // Discord ID của admin thực hiện
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Transaction', transactionSchema);
