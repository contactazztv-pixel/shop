const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String, default: '' },
  price: { type: Number, required: true, min: 0 },
  type: {
    type: String,
    enum: ['rank', 'item', 'account', 'service', 'other'],
    default: 'other'
  },
  server: { type: String, default: '' }, // e.g. DonutSMP, KingSMP
  emoji: { type: String, default: '🎁' },
  badge: { type: String, default: '' }, // e.g. HOT, NEW, SALE
  badgeColor: { type: String, default: 'blue' },
  stock: { type: Number, default: -1 }, // -1 = unlimited
  sold: { type: Number, default: 0 },
  isActive: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Product', productSchema);
